
function ratingEnable() {
$('.rating-scale').barrating('show', {
theme: 'bars-square',
showValues: true,
showSelectedRating: false
});
}
eform = '';
jsonObj = [];
$.validator.addMethod("phoneregx", function(value, element) {
    return this.optional(element) || value == value.match(/^[\d+ ]*$/);
}, "Please enter a valid phone number");
var currentform;
i = 1;
j = 0;
var prelbl = '';
var predesc = '';
var pretxttitle ='';
var pretxtsubtitle = '';
var cm = {};
var editorcount = 1;
htmlClasses = {activeClass: "active",hiddenClass: "hidden",visibleClass: "visible",editFormClass: "edit-form",
animatedVisibleClass: "animated fadeIn",animatedHiddenClass: "animated fadeOut",animatingClass: "animating"}
$( document ).ready(function() {
      var options1 = {
        hour: {
            value: 0,
            min: 0,
            max: 24,
            step: 1,
            symbol: "hrs"
        },
        minute: {
            value: 0,
            min: 0,
            max: 60,
            step: 1,
            symbol: "mins"
        },
        direction: "increment", // increment or decrement
        inputHourTextbox: null, // hour textbox
        inputMinuteTextbox: null, // minutes textbox
        postfixText: "", // text to display after the input fields
        numberPaddingChar: '0' // number left padding character ex: 00052
    };
     $("#pubtimer").timesetter(options1).setHour(0);
	$(".thankyou").hide();
	$('#file_range').slider({ 
        val: 1, 
        min: 1,
        max: 20,
        onChange: function(e, val) {
          $(this).next('span').text(val);
		  fileacceptclick('');
        },
        onLoad: function(e, val) {
          $(this).next('span').text(val);
		  fileacceptclick('');
        }
      });
	  $('#image_range').slider({ 
        val: 90, 
        min: 10,
        max: 100,
        onChange: function(e, val) {
          $(this).next('span').text(val+"%");
		  $("#selectimagealign").trigger("change");
        },
        onLoad: function(e, val) {
          $(this).next('span').text(val+"%");
		  $("#selectimagealign").trigger("change");
        }
      });
	  $('#scale_range').slider({ 
        val: 10, 
        min: 5,
        max: 20,
        onChange: function(e, val) {
          $(this).next('span').text(val);
		  bindRatinbgScale(val)
        },
        onLoad: function(e, val) {
          $(this).next('span').text(val);
		  bindRatinbgScale(val)
        }
      });
	prelbl = new inLine('#inplblName', {
		toolbar: ["bold","italic","underline","link"],
		theme: "light "});
	predesc = new inLine('#inplblDesp', {
		toolbar: ["bold","italic","underline","link"],
		theme: "light "});
	pretxttitle = new inLine('#inplbltitletxt', {
		toolbar: ["bold","italic","underline","link"],
		theme: "light "});
	pretxtsubtitle = new inLine('#inplblsubtitletxt', {
		toolbar: ["bold","italic","underline","link"],
		theme: "light "});
	$(document).on("submit", "form", function (event) {
		event.preventDefault();
		var formvalid1 = checkForValidForm();
		if(formvalid1 != null && formvalid1 != 'undefined' && formvalid1 != false){
		fieldtype =  $('#'+currentform).attr("data-type");
		if((fieldtype == "titleField") || (fieldtype == "descField") || (fieldtype == "imageField") ||  (fieldtype == "welcomestep"))
		{
					
		}
		else{
			formdtls = $('form').find("#"+currentform);
			mtrix = formdtls.find('.tblmtrix input[type=radio]:checked').map(function(){return this.value;}).get().join(",");
			chk = formdtls.find('input:checkbox:checked').map(function(){return this.value;}).get().join(",");
			rad = formdtls.find('input:radio:checked').map(function(){return this.value;}).get().join(",");
			question = formdtls.find(".lbl").text().trim();
			inputs = formdtls.find("input, textarea,select").val().trim();
			item = jsonObj.find(x => x.question == question);
			answer = ''
			if(chk.length!=0){answer = chk;}
			else if(rad.length!=0){answer = rad;}
			else if(mtrix.length!=0){answer = mtrix;}
			else{answer = inputs;}
			if (item) {
				item.answer = answer.trim();
			}
			else{
				item = {}
				item ["question"] = question;
				item ["answer"] = answer.trim();
				jsonObj.push(item);
			}
		console.log(jsonObj);
		}
  $(".multi-step-form").hide();
  $(".thankyou").show();
  
   	$('.pie_progress').asPieProgress({
        namespace: 'pie_progress',
		min: 0,
		max: 100,
		numberCallback: function(n) {
		var percentage = this.getPercentage(n);
		$('.pie_progress__number').text(percentage+" %");
		$('.pie_progress svg path').attr("stroke", "green");
		},
	});
	$('.pie_progress').asPieProgress('start');
}
else{
	console.log("not valid");
}
});
});
function Addbtnclick(){
	 $("#addelemdiv").show();
	  $("#divelements").hide();
}

function AddSectionClose(){
	 $("#addelemdiv").hide();
	  $("#divelements").show();
}
function txtchange(id)
{
	listId = $("#eleId").val();
	objIndex = questionobject.findIndex((obj => obj.id == listId));
	if(id=='elelabl')
	{
		questionobject[objIndex].title = $("#elelabl").val();
	}
}
function addelement(id)
{
	prevval = ''
	if(i == 1)
	{
		prevval = 'step-0';
	}
	else{
		k = (parseInt(i)-1)
		prevval = 'fieldques'+k.toString();
	}
	currentelem = 'ques'+i.toString();
	idnextval = 'fieldques'+(parseInt(i)+1).toString();
	if(id=="shortText"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Short Text';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control input" type="text" data-type="text" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" ><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-i-cursor"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
		//setupAria();
	}
	else if(id=="longText"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Long Text';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div>	<textarea class="form-control" rows="3" data-type="text" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" ></textarea><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-paragraph"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
		//setupAria();
	}
	else if(id=="editorText"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Editor Text';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><label class="editorlbl">Choose Language: </label><select  id="editorsel'+i+'" class="form-control input editorsel" onchange="inputeditoronChange(this.id)" data type="code-select"><option value="htmlmixed">HTML/CSS/Jquery</option><option value="text/x-csrc">C</option><option value="text/x-c++src">C++</option><option value="text/x-python">Python</option><option value="application/x-httpd-php">PHP</option><option value="text/x-java">Java</option><option value="text/javascript">JavaScript</option><option value="text/jsx">React</option></select><textarea class="editorcontrol" id="codeedit'+i+'" rows="5" data-type="code" ></textarea><span id="errorcode'+i+'" class="sperrorcode">This code is required.</span><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-edit"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
		//setupAria();
	}
	else if(id=="emailAddress"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Email Address';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control input" type="email" name="email" data-type="email" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="far fa-envelope"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="phoneNumber"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Phone Number';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control phone" placeholder= "(456)-345-2312" data-type="phone" name="phone" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" ><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-phone"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="passwordField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Password';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control input" type="password" name="password" data-type="password" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" ><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-eye-slash"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="dateField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Date';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control date"  type="date" onchange="inputonChange(this)" data-type="date" onkeypress="inputonkeypress(this)"></input><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="far fa-calendar-alt"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="numberField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Number';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input class="form-control number" onkeydown="preventkeys(event)" type="number" data-type="number" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-hashtag"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="multipleChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Multiple Choice';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div class="checkbox-group"><div class="p-2 rounded checkbox-form"><div class="form-check"> <input class="form-check-input" type="checkbox" data-type="choice" name="check[]" id="check1" value="Option 1" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"> <label class=" form-check-label" for="check1"> Option 1 </label> </div></div><div class="p-2 rounded checkbox-form"><div class="form-check"> <input class="form-check-input" type="checkbox" name="check[]" data-type="choice" value="Option 2" id="check2" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" > <label class=" form-check-label" for="check2"> Option 2 </label> </div></div> <div class="p-2 rounded checkbox-form"><div class="form-check"> <input class="form-check-input" type="checkbox" name="check[]"  data-type="choice" value="Option 3" id="check3" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"> <label class="form-check-label" for="check3"> Option 3 </label> </div></div><div class="p-2 rounded checkbox-form"><div class="form-check"> <input class="form-check-input" type="checkbox" name="check[]" data-type="choice" value="Option 4" id="check4" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" > <label class="form-check-label" for="check4"> Option 4 </label> </div></div></div><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-check-square"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="singleChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Single Choice';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div class="radiochoice"><div class="p-2 rounded radio-form"><div class="form-radio"> <input class="form-radio-input" type="radio" name="single[]" data-type="choice" value="Option 1" id="radio1" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" > <label class="form-radio-label" for="radio1"> Option 1</label> </div></div><div class="p-2 rounded radio-form"><div class="form-radio"> <input class="form-radio-input" type="radio" name="single[]" data-type="choice" value="Option 2" id="radio2" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"> <label class="form-radio-label" for="radio2"> Option 2</label> </div></div><div class="p-2 rounded radio-form"><div class="form-radio"> <input class="form-radio-input" type="radio" name="single[]" data-type="choice" value="Option 3" id="radio3" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"> <label class="form-radio-label" for="radio3"> Option 3</label> </div></div><div class="p-2 rounded radio-form"><div class="form-radio"> <input class="form-radio-input" type="radio" name="single[]" data-type="choice" value="Option 4" id="radio4" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" > <label class="form-radio-label" for="radio4"> Option 4</label> </div></div></div><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-check-circle"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="imageChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Image Choice';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div class="divImageChoice"><div class="p-2 rounded image-form"><input type="radio" id="image1"  class="form-image-input" name="image[]" data-type="choice" value="Option 1" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"/><label for="image1"><div class="topdiv"><img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" /></div><div class="spandiv"><span> Option 1</span></div></label></div><div class="p-2 rounded image-form"><input type="radio" id="image2"  value="Option 2" data-type="choice"  class="form-image-input" name="image[]" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"/><label for="image2"><div class="topdiv"><img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" /></div><div class="spandiv"><span> Option 2</span></div></label></div><div class="p-2 rounded image-form"><input type="radio" id="image3" value="Option 3" data-type="choice"  class="form-image-input" name="image[]" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" /><label for="image3"><div class="topdiv"><img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" /></div><div class="spandiv"><span> Option 3</span></div></label></div><div class="p-2 rounded image-form"><input type="radio" id="image4" value="Option 4" data-type="choice"  class="form-image-input" name="image[]" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"/><label for="image4"><div class="topdiv"><img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" /></div><div class="spandiv"><span> Option 4</span></div></label></div></div><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="far fa-images"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="dropdownChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='DropDown';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><select  class="form-control input" onchange="inputonChange(this)" data-type="select" onkeypress="inputonkeypress(this)"><option value="Option 1">Option 1</option><option value="Option 2">Option 2</option><option value="Option 3">Option 3</option><option value="Option 4">Option 4</option></select><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-chevron-circle-down"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="reviewChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Scale';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div class="box box-orange box-example-1to10"><div class="box-body"> <select class="rating-scale" name="rating" data-type="select" autocomplete="off"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7" selected="selected">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select> </div></div><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fab fa-cloudscale"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
		ratingEnable();
	}
	else if(id=="matrixChoice"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Matrix Choice';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div id="matrix_wrap"><table class="tblmtrix"><tr><th></th><th>Negative</th><th>Neutral</th><th>Positive</th></tr><tr><td>Row 1</td><td><input type="radio" name="row-1" data-col="1"  value="Negative1" data-type="matrix" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td><td><input type="radio" name="row-1" data-col="2" value="Neutral1" data-type="matrix" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td><td><input type="radio" name="row-1" data-col="3" data-type="matrix" value="Positive1" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td></tr><tr><td>Row 2</td><td><input type="radio" name="row-2" data-col="1" value="Negative2" data-type="matrix" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td><td><input type="radio" name="row-2" data-col="2" value="Neutral2" data-type="matrix" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td><td><input type="radio" name="row-2" data-col="3" value="Positive2" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)"></td></tr></table></div><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-th"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="fileUpload"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='File Upload';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input type="file" class="multi" data-type="file" onchange="inputonChange(this)" onkeypress="inputonkeypress(this)" ><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-upload"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="audioUpload"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Audio';
		idbody='audiobody';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input type="text" class="audiourl" data-type="link" value=""><a class="audioclck" onclick="audioclick(this);"><i class="fas fa-microphone-alt"></i></a><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-volume-up"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="videoUpload"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Video';
		idbody='videobody';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input type="text" class="videourl" data-type="link" value=""><a class="videoclck" onclick="videoclick(this);"><i class="fas fa-video"></i></a><div class="supportlbl"><span>Description</span></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-video"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="titleField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Title';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><div class="supportlbl"></div><input type="hidden" class="txt" value="1"></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-heading"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}	
	else if(id=="descField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Description';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbldesc"><span>'+idText+'</span></div><input type="hidden" class="desc" value="1"></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-align-right"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	else if(id=="imageField"){
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		idText ='Image';
		htmltxt = '<fieldset id="'+idval+'" data-type="'+id+'"><p>	<button class="btn btn-default btn-prev" type="button" aria-controls="'+prevval+'" onclick="prevbtnclick(this);"><i class="far fa-arrow-alt-circle-up"></i>Return</button></p><p><div class="lbl"><span>'+idText+'</span></div><input type="hidden" class="img" value="1" ><div style="text-align: right;"><img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" alt=""></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		$("#formelements").append(htmltxt);
		$("#lielemnts").append('<li class="'+elidval+'" ><a class="lielement" id="'+elidval+'" onclick="elemclick(this.id);" data-label= "'+id+'"><i class="fas fa-image"></i><span class="count">'+i+'. </span><span class="linktext">'+idText+'</span></a> <a class="delicon"  onclick="deleteclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-trash-alt"></i></a><a class="dupicon" onclick="duplicateclick(this);" data-label= "'+idval+'" data-value= "'+elidval+'"><i class="far fa-copy"></i></a></li>');
		$("#eleId").val(idval);
		$("#elelabl").val(idText);
	}
	sortitems('sort','','fieldques'+i.toString());
	i= parseInt(i)+1;
	$('#'+currentelem).trigger('click');
}

function getWords(str) {
    return str.split(/\s+/).slice(0,5).join(" ");
}

function elemclick(e)
{
	$("#mycusprop li:first-child a").trigger('click');
	datalable = $("#"+e).attr("data-label");
	$("#helemtid").val(e);
	$("#helemttype").val(datalable);
	$(".readonlydiv").show();
	$(".hiddendiv").show();
	if(datalable =="shortText" || datalable =="emailAddress" || datalable =="phoneNumber" || datalable =="passwordField")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname);
		eml= $('#'+field).find('input')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if ($('#'+field).find('input').css('display') == 'none' || $('#'+field).find('input').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		setupAria(field);
	}
	else if(datalable =="longText" )
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$('#textAreafields').show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname);
		eml= $('#'+field).find('textarea')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if(eml.hasAttribute('maxlength')) {
			$("#inplblMaxChar").val($(eml).attr("maxlength"));
		} else {
			$("#inplblMaxChar").val('');
		}
		if ($('#'+field).find('textarea').css('display') == 'none' || $('#'+field).find('textarea').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		setupAria(field);
	}
	else if(datalable =="dateField")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$('#datefields').show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname);
		eml= $('#'+field).find('input[type=date]')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if(eml.hasAttribute('min')) {
			$("#inplblMinDate").val($(eml).attr("min"));
		} else {
			$("#inplblMinDate").val('');
		}
		if(eml.hasAttribute('max')) {
			$("#inplblMaxDate").val($(eml).attr("max"));
		} else {
			$("#inplblMaxDate").val('');
		}
		if ($('#'+field).find('input[type=date]').css('display') == 'none' || $('#'+field).find('input[type=date]').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		setupAria(field);
	}
	else if(datalable =="numberField")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$('#numberfields').show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname);
		eml= $('#'+field).find('input[type=number]')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if(eml.hasAttribute('min')) {
			$("#inplblMinNumb").val($(eml).attr("min"));
		} else {
			$("#inplblMinNumb").val('');
		}
		if(eml.hasAttribute('max')) {
			$("#inplblMaxNumb").val($(eml).attr("max"));
		} else {
			$("#inplblMaxNumb").val('');
		}
		if ($('#'+field).find('input[type=number]').css('display') == 'none' || $('#'+field).find('input[type=number]').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		setupAria(field);
	}
	else if(datalable =="multipleChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
			    $('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#selectoptions').show();
		$('#divseldfault').show();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		setupAria(field);
	}
	else if(datalable =="singleChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#selectoptions').show();
		$('#divseldfault').show();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		setupAria(field);
	}
	else if(datalable =="dropdownChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#selectoptions').show();
		$('#divseldfault').show();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		eml= $('#'+field).find('select')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if ($('#'+field).find('select').css('display') == 'none' || $('#'+field).find('select').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		$("#bindoptions").empty();
		$("#selectdefault").empty();
		$('#'+field).find("select option").each(function(i){
			$("#bindoptions").append('<div class="row divoptions" id="'+(i+1)+'"><div class="col-sm-12 divalue"><input class="pro-controls" type="text" data-label="option" data-area="value" placeholder="value" value="'+$(this).val()+'" onchange="optionvalOnchange('+(i+1)+')"><button class="btnopticons" onclick="Deleteoptnbtnclick('+(i+1)+');"> <i class="far fa-trash-alt"></i> </button></div><div class="col-sm-12 divlabel"><input class="pro-controls" type="text" data-label="option" data-area="label" value="'+$(this).text()+'" onchange="optionlblOnchange('+(i+1)+')" style="display: none;" placeholder="label"></div></div>')
			$("#selectdefault").append('<option value="'+$(this).val()+'">'+$(this).text()+'</option>');
		});
		$('#selectdefault').val($('#'+field).find("select").val())
		setupAria(field);
	}
	else if(datalable =="imageChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").text();
		destxt = $(fieldid).find(".supportlbl span").text();
		$("#inplblName").text(quetxt);
		$("#inplblDesp").text(destxt);
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$('#imageoptions').show();
		$('#divseldfault').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname),
		setupAria(field);
	}
	else if(datalable =="reviewChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
			    $('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#scalefields').show();
		$('#commonproperties').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		setupAria(field);
	}
	else if(datalable =="matrixChoice")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").text();
		destxt = $(fieldid).find(".supportlbl span").text();
		$("#inplblName").text(quetxt);
		$("#inplblDesp").text(destxt);
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$('#matrixoptions').show();
		$('#divseldfault').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname),
		setupAria(field);
	}
	else if(datalable =="fileUpload")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$('#filefields').show();
		$(".thankyou").hide();
		field= 'field'+e;
		eml= $('#'+field).find('input[type=file]')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		if(eml.hasAttribute('readonly')) {
			$('#chklblRead').prop('checked', true);
		} else {
			$('#chklblRead').prop('checked', false);
		}
		if(eml.hasAttribute('maxfiles')) {
			$("#file_val").text($(eml).attr("maxfiles"));
			$('#file_range').slider('setVal', parseInt($(eml).attr("maxfiles")));
		} 
		else {
			$("#file_val").text('1');
			$('#file_range').slider('setVal', 1);
		}
		if(eml.hasAttribute('accept')) {
			$("#filefields").find('input[type=checkbox]').prop("checked", false);
			var array = $(eml).attr("accept").split(',');
			for (let i = 0; i < array.length; i++) {
				lbl = $("#filefields").find("label:contains("+array[i]+")").attr("for");
				$("#filefields").find('#'+lbl).prop("checked", true);
			}
		} 
		else {
			$("#filefields").find('input[type=checkbox]').prop("checked", false);
			$("#filefields").find('input[type=checkbox]').prop("checked", true);
			fileacceptclick('');
		}
		if ($('#'+field).find('input[type=file]').css('display') == 'none' || $('#'+field).find('input[type=file]').css("visibility") == "hidden"){
			$('#chklblHidd').prop('checked', true);
		} 
		else {
			$('#chklblHidd').prop('checked', false);
		}
		setupAria(field);
	}
	else if(datalable =="audioUpload" || datalable =="videoUpload" || datalable =="editorText")
	{
		fieldid = '#field'+e;
		quetxt = $(fieldid).find(".lbl span").html();
		destxt = $(fieldid).find(".supportlbl span").html();
		prelbl.destroy();
		prelbl = new inLine('#inplblName', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplblName")[0].innerHTML);
				$('#'+eleid).find('.linktext').text(getWords($("#inplblName").text()));
			  }
		  });
		predesc.destroy();
		predesc  =new inLine('#inplblDesp', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				desctext = $(fieldid).find('.supportlbl span');
				desctext.html($("#inplblDesp")[0].innerHTML);
			  }
		  });
		  $(".readonlydiv").hide();
		  $(".hiddendiv").hide();
		$('.advancefields').hide();
		$('#commonproperties').show();
		$('#accordion').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		eml= $('#'+field).find('input,textarea')[0];
		if(eml.hasAttribute('required')) {
			$('#chklblReq').prop('checked', true);
		} else {
			$('#chklblReq').prop('checked', false);
		}
		setupAria(field);;
	}

	else if(datalable =="titleField")
	{
		$('.advancefields').hide();
		$('#Titlefields').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		fieldname = 'fieldset#field'+e;
		field= 'field'+e;
		showField = $("#formelements").find(fieldname),
		ttltxt = $("#"+field).find(".lbl span").html();
		subtltxt = $("#"+field).find(".supportlbl span").html();
		pretxttitle.destroy();
		pretxttitle = new inLine('#inplbltitletxt', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:ttltxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
				fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.lbl span');
				labtext.html($("#inplbltitletxt")[0].innerHTML);
			}
		});
		pretxtsubtitle.destroy();
		pretxtsubtitle = new inLine('#inplblsubtitletxt', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:subtltxt,
			onChange: function (api) {
				eleid = $("#helemtid").val();
		 		fieldid= '#field'+eleid;
				labtext = $(fieldid).find('.supportlbl');
				labtext.html($("#inplblsubtitletxt")[0].innerHTML);
			  }
		  });
		setupAria(field);
	}
	else if(datalable =="descField")
	{
		$('.advancefields').hide();
		$('#Descfields').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		desctxt = $("#"+field).find(".lbldesc span").html();
		$('#inplbldescedittxt').summernote({
			tabsize: 2,
			height: 50,
			toolbar: [
			  ['style', ['style']],
			  ['font', ['bold', 'italic', 'underline', 'clear']],
			  ['para', ['ul', 'ol', 'paragraph']],
			  ['insert', ['link']],
			],
			callbacks: {
				onChange: function(contents, $editable) {
					eleid = $("#helemtid").val();
					fieldid= '#field'+eleid;
					labtext = $(fieldid).find('.lbldesc span');
					console.log(contents);
					labtext.html(contents);	
				}
			  }
		  });
		$('#inplbldescedittxt').summernote('code', desctxt);
		setupAria(field);
	}
	else if(datalable =="imageField")
	{
		$('.advancefields').hide();
		$('#Imagefields').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'field'+e;
		eml= $('#'+field).find('img')[0];
		width= eml.style.width;
		mright= eml.style.marginRight;
		mleft= eml.style.marginLeft ;
		if(width.length==0 && mright.length==0 && mleft.length==0 )
		{
			$('#image_range').slider('setVal', 90);
			$("#selectimagealign").trigger("change");
		}
		else{
			if(mright=='auto' && mleft =='auto')
			{
				$("#selectimagealign").val('center');
			}
			else if(mright=='0px' && mleft =='auto')
			{
				$("#selectimagealign").val('right');
			}
			else if(mright=='auto' && mleft =='0px')
			{
				$("#selectimagealign").val('left');
			}
			wval = width.replace('%', '')
			$('#image_range').slider('setVal', parseInt(wval));
		}
		setupAria(field);
	}
	else if(datalable =="welcomeText")
	{
		$('.advancefields').hide();
		$('#welcomefields').show();
		$(".multi-step-form").show();
		$(".thankyou").hide();
		field= 'welcomestep';
		quetxt = $("#"+field).find(".lblti span").text();
		destxt = $("#"+field).find(".lbldesc span").text();
		new inLine('#inputwtitle', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				fieldid= '#welcomestep';
				labtext = $(fieldid).find('.lblti span');
				labtext.html($("#inputwtitle")[0].innerHTML);
			  }
		  });
		  new inLine('#inputwdesc', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				fieldid= '#welcomestep';
				labtext = $(fieldid).find('.lbldesc span');
				labtext.html($("#inputwdesc")[0].innerHTML);
			  }
		  });
		setupAria(field);
	}
	else if(datalable =="thankYouText")
	{
		$('.advancefields').hide();
		$('#thankfields').show();
		$('form').hide();
		$('.thankyou').show();
		fieldid = '.thankyou';
		quetxt = $(fieldid).find(".lblti span").text();
		destxt = $(fieldid).find(".lbldesc span").text();
		new inLine('#inputthtitle', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:quetxt,
			onChange: function (api) {
				labtext = $(fieldid).find('.lblti span');
				labtext.html($("#inputthtitle")[0].innerHTML);
			  }
		  });
		  new inLine('#inputthdesc', {
			toolbar: ["bold","italic","underline","link"],
			theme: "light ",
			html:destxt,
			onChange: function (api) {
				labtext = $(fieldid).find('.lbldesc span');
				labtext.html($("#inputthdesc")[0].innerHTML);
			  }
		  });
	}
}
	
function setupAria(currentID){
	$('form').show();
	currentID = currentID.replace("#",'');
	var $formParent = $(".multi-step-form");
	var $form = $formParent.find("form");
	var $formStepParents = $form.find("fieldset");
	 $("fieldset").hide();
	 $("#"+currentID).show();
	 var config = {
		mode: "htmlmixed",
		extraKeys: {"Ctrl-Space": "autocomplete"},
		indentWithTabs: true,
		smartIndent: true,
		lineNumbers: true,
		lineWrapping: true,
		matchBrackets: true,
		autofocus: true,
		keyMap:"sublime",
		tabSize:4,
	};
	var fieldtype =  $('#'+currentID).attr("data-type");
	if(currentID!= "welcomestep" && fieldtype == "editorText")
	{
		var textareachk  = $("#"+currentID).find('textarea')[0];
		if(textareachk != null)
		{
			var clastxt = $("#"+currentID).find('textarea').attr('class');
			if(clastxt == 'editorcontrol')
			{
				var exits = $("#"+currentID).find('.cm-s-material-ocean');
				if(exits.length == 0) {
					cm['cm' + editorcount]  = CodeMirror.fromTextArea($("#"+currentID).find('textarea')[0],config);
					cm['cm' + editorcount].setOption("theme", "material-ocean");
					editorcount++;	
				}
			}
		}
		$("#"+currentID).find(".sperrorcode").hide();
	}
	else{
		var firstpreviousbutn = $form.find("[aria-controls='step-0']");
		firstpreviousbutn.addClass(htmlClasses.hiddenClass).attr("aria-hidden",true);
		$("#"+currentID).find("input,textarea,select").focus();
		var elem = $("#"+currentID).find("input,textarea,select")[0];
		if(elem != null)
		{
		if(elem.hasAttribute('required')){
			$("#"+currentID).find(".controls").addClass(htmlClasses.hiddenClass).attr("aria-hidden",true);
		   }
		   else{
			   $("#"+currentID).find(".controls").removeClass(htmlClasses.hiddenClass).attr("aria-hidden",false);
		   }
		}
	}
	currentform = currentID;
	handleAriaExpanded();	
	}
		
 function handleAriaExpanded(){
		$.each(this.$nextButton, function(idx,item){
			var controls = $(item).attr("aria-controls");
			if($("#"+controls).attr("aria-hidden") == "true"){
				$(item).attr("aria-expanded",false);
			}else{
				$(item).attr("aria-expanded",true);
			}
		});

		$.each(this.$prevButton, function(idx,item){
			var controls = $(item).attr("aria-controls");
			if($("#"+controls).attr("aria-hidden") == "true"){
				$(item).attr("aria-expanded",false);
			}else{
				$(item).attr("aria-expanded",true);
			}
		});

	}
	
	function checkForValidForm(){
		var fieldtype =  $('#'+currentform).attr("data-type");
		if(fieldtype =="editorText")
		{
			var textareatxt = $("#"+currentform).find("textarea")[0];
			if(textareatxt.hasAttribute('required'))
			{
				var codeInstance = $("#"+currentform).find(".CodeMirror")[0].CodeMirror;
				var code = codeInstance.getValue();
				if(code.length==0)
				{
					console.log("not valid");
					$("#"+currentform).find(".sperrorcode").show();
					return false;
				}
				else{
					console.log("valid");
					$("#"+currentform).find(".sperrorcode").hide();
					return true;
				}
			}
			else{
				validateForm();
				if($("form").valid()){
					$("#"+currentform).find(".controls").removeClass(htmlClasses.hiddenClass).attr("aria-hidden",false);
					return true;
				}
			}
		}
		else{
			validateForm();
			if($("form").valid()){
				$("#"+currentform).find(".controls").removeClass(htmlClasses.hiddenClass).attr("aria-hidden",false);
				return true;
			}
		}
	}
	function inputonkeypress(e){
		checkForValidForm();
	}
	function inputonChange(e){
		checkForValidForm();
	}
	function validateForm(){
		this.$("form").validate({
			 rules: {
				email: {
					email: true
				},
				phone: {
					phoneregx: true
				},
				password: {
					minlength:8,
					maxlength:16,
				},
			 },
			messages: {	
			email: {
				email: "Please enter a valid e-mail",
				},
			phone: {
				phoneregx: "Please enter a valid phone Number",
				},
			password: {
				minlength:  "Password should be minimum 8 characters",
				maxlength:  "Password should be maximum 16 characters",
				},
			},
			ignore: ":hidden", 
			errorElement: "span", 
			errorClass: "error-text",
			errorPlacement: function(error, element) {  // Sarah added to insert before to work better with radio buttions
				if(element.attr("type") == "radio") {
					error.insertBefore(element);
				}
				else
				{
					error.insertAfter(element);
				}
			},
			invalidHandler: function(event, validator){ // add aria-invalid to el with error
				$.each(validator.errorList, function(idx,item){
					if(idx === 0){
						$(item.element).focus(); // send focus to first el with error
					}
					$(item.element).attr({"aria-invalid": true, "aria-required": true}); 
				})
			}
		});
	}
	
	function prevbtnclick(e)
	{
		currentParent = $(e).closest("fieldset"),
		prev = "#"+currentParent.find(".btn-prev").attr("aria-controls");
		prevParent = $('form').find(prev),
		currentform = prev;
		currentParent.removeClass(htmlClasses.visibleClass);
		setupAria(prev);
	}
	
	function nextbtnclick(e)
	{	
		currentParent = $(e).closest("fieldset"),
		next = "#"+currentParent.find(".btn-enter").attr("aria-controls");
		nextParent = $('form').find(next),
		formvalid1 = checkForValidForm();
		if(formvalid1 != null && formvalid1 != 'undefined' && formvalid1 != false){
			fieldtype =  $('#'+currentform).attr("data-type");
			if((fieldtype == "titleField") || (fieldtype == "descField") || (fieldtype == "imageField") ||  (fieldtype == "welcomestep"))
			{
				currentform = next;
				setupAria(next);
			}
			else{
				formdtls = $('form').find("#"+currentform);
				mtrix = formdtls.find('.tblmtrix input[type=radio]:checked').map(function(){return this.value;}).get().join(",");
				chk = formdtls.find('input:checkbox:checked').map(function(){return this.value;}).get().join(",");
				rad = formdtls.find('input:radio:checked').map(function(){return this.value;}).get().join(",");
				question = formdtls.find(".lbl").text().trim();
				inputs = formdtls.find("input, textarea,select").val().trim();
				item = jsonObj.find(x => x.question == question);
				answer = ''
				if(chk.length!=0){answer = chk;}
				else if(rad.length!=0){answer = rad;}
				else if(mtrix.length!=0){answer = mtrix;}
				else{answer = inputs;}
				if (item) {
					item.answer = answer.trim();
				}
				else{
					item = {}
					item ["question"] = question;
					item ["answer"] = answer.trim();
					jsonObj.push(item);
				}
				currentform = next;
				setupAria(next);
			}

		}
		else{
			console.log("not valid");
		}
	}
	function enterbtnclick(e){
		currentParent = $(e).closest("fieldset"),
		next = "#"+currentParent.find(".btn-enter").attr("aria-controls");
		nextParent = $('form').find(next),
		formvalid1 = checkForValidForm();
		if(formvalid1 != null && formvalid1 != 'undefined' && formvalid1 != false){
			fieldtype =  $('#'+currentform).attr("data-type");
			if((fieldtype == "titleField") || (fieldtype == "descField") || (fieldtype == "imageField") ||  (fieldtype == "welcomestep"))
			{
				currentform = next;
				setupAria(next);
			}
			else{
				formdtls = $('form').find("#"+currentform);
				mtrix = formdtls.find('.tblmtrix input[type=radio]:checked').map(function(){return this.value;}).get().join(",");
				chk = formdtls.find('input:checkbox:checked').map(function(){return this.value;}).get().join(",");
				rad = formdtls.find('input:radio:checked').map(function(){return this.value;}).get().join(",");
				question = formdtls.find(".lbl").text().trim();
				inputs = formdtls.find("input, textarea,select").val().trim();
				item = jsonObj.find(x => x.question == question);
				answer = ''
				if(chk.length!=0){answer = chk;}
				else if(rad.length!=0){answer = rad;}
				else if(mtrix.length!=0){answer = mtrix;}
				else{answer = inputs;}
				if (item) {
					item.answer = answer.trim();
				}
				else{
					item = {}
					item ["question"] = question;
					item ["answer"] = answer.trim();
					jsonObj.push(item);
				}
				currentform = next;
				setupAria(next);
			}

		}
		else{
			console.log("not valid");
		}
	}
	
	function deleteclick(e)
	{
		var eleid ="."+ $(e).attr("data-value");
		var formfieldId ="#"+   $(e).attr("data-label");
		firstlist = $('#lielemnts li').find('a:first').attr('id');
		count= firstlist.match(/\d+/);
		curvalind = 'fieldques'+parseInt(count).toString();
		$('#lielemnts').find(eleid).remove();
		$('form').find(formfieldId).remove();
		lilength= $('#lielemnts li a.lielement').length;
		if(lilength>0)
		{
			lastlist = $('#lielemnts li:last-child').find('a').attr('id');
			lcount= lastlist.match(/\d+/);
			fieldlast = 'fieldques'+parseInt(lcount).toString();
			controls = $("#"+fieldlast).find('.controls');
			controls.empty();
			controls.append('<button class="btn btn-default" type="submit">Submit</button> ');
		}
		sortitems('sort','',curvalind);
	}
	
	function duplicateclick(e)
	{
		var eleid ="." + $(e).attr("data-value");
		var formfieldId ="#"+   $(e).attr("data-label");
		idval ='fieldques'+i.toString();
		elidval ='ques'+i.toString();
		$('#lielemnts').append($(eleid).clone().prop('class', elidval)).html();
		formfieldshtml = $(formfieldId).clone().prop('id', idval );
		controls = formfieldshtml.find('.controls');
		controls.empty();
		controls.append('<button class="btn btn-default" type="submit">Submit</button> ');
		$('form').append(formfieldshtml).html();
		sortitems('insert',elidval,idval);
	}
	function sortitems(action,elem,fieldID){
		if(action=='sort')
		{
			m = 1;
			n= 1;
			$("#lielemnts li a.lielement").each(function() {
				id = 'fieldset#field'+$(this).attr("id");
				serial = $(this).find('span.count');
				serial.text(m+ ' .');
				m= parseInt(m)+1;
			});
			var idlists	= [];
			$("form fieldset").each(function() {
				if (this.id) {
					idlists.push(this.id);
				}
			});
			const welind = idlists.indexOf('welcomestep');
			if (welind > -1) {
				idlists.splice(welind, 1);
				}
			if(idlists.length != 0)
			{
			var result = $("#togBtn")[0].checked ? 'yes' : 'no';
			if(result=='yes'){
				firstlist = $('#lielemnts li').find('a:first').attr('id');
				count= firstlist.match(/\d+/);
				curvalind = 'fieldques'+parseInt(count).toString();
				indcuval = idlists.indexOf(curvalind);
				idnextval = idlists[indcuval]
				prevval= 'step-0';
				field= $('form').find("#welcomestep");
				prev = field.find('.btn-prev');
				prev.attr('aria-controls',prevval);
				controls = field.find('.controls');
				controls.empty();
				controls.append('<button class="btn btn-default btn-next" type="button" aria-controls="'+idnextval+'" onclick="nextbtnclick(this);">Next</button><button class="btn btn-default btn-enter" type="button" aria-controls="'+idnextval+'" onclick="enterbtnclick(this);">Press <span class="f-string-em" >Enter</span></button>');		
				sortfields('welcomestep',idlists);		
			}
			else{
				sortfields('step-0',idlists);	
			}
			}
			setupAria(fieldID);
		}
		else if(action=='insert')
		{
			elmId = '.'+elem;
			litem = $('#lielemnts').find(elmId);
			count= elem.match(/\d+/);
			prevval =  'fieldques' + (parseInt(count)-1).toString();
			idnextval =  'fieldques' + (parseInt(count)+1).toString();
			anelem= litem.find('a.lielement');
			anelem.attr('id',elem);
			serial = $(anelem).find('span.count');
			serial.text(count+ ' .');
			filedId = 'field'+elem;
			andelelem= litem.find('a.delicon');
			andelelem.attr('data-label',filedId);
			andelelem.attr('data-value',elem);
			andupelem= litem.find('a.dupicon');
			andupelem.attr('data-label',filedId);
			andupelem.attr('data-value',elem);
			field= $('form').find(filedId);
			prev = field.find('.btn-prev');
			prev.attr('aria-controls',prevval);
			prev.removeClass("hidden");
			next = field.find('.btn-next');
			next.attr('aria-controls',idnextval);
			enter = field.find('.btn-enter');
			enter.attr('aria-controls',idnextval);
			i = parseInt(i)+1;
			sortitems('sort','',filedId);
		}
	}
	
 function switchclilck(cb) {
	 if(cb.checked){
		$(".welcomediv").show();
		 htmltxt = '<fieldset id="welcomestep" data-type="welcomestep"><p><div class="welcome"><div class="media"><input type="hidden" class="hwelcome" value="1">	<img src="https://i.ibb.co/KG3BzLz/31314483-7611c488-ac0e-11e7-97d1-3cfc1c79610e.png" alt=""></div><div class="title">	<div class="lblti"><span>Text</span></div></div><div class="descrip"><div class="lbldesc"><span>Description</span></div></div></div></p><p class="controls"><button class="btn btn-default" type="submit">Submit</button> </p></fieldset>'
		 $("#formelements").append(htmltxt);
		 firstlist = $('#lielemnts li').find('a:first').attr('id');
		 console.log(firstlist);
		 if(firstlist ==null)
		 {
			 sortitems('sort','','welcomestep');
			 currentform='welcomestep';
			 $('#welcome').trigger('click');
		 }
		 else{
			 $(".thankyou").hide();
			 count= firstlist.match(/\d+/);
			 curvalind = 'fieldques'+parseInt(count).toString();
			 currentform=curvalind;
			 sortitems('sort','',curvalind);
			 $('ques'+parseInt(count).toString()).trigger('click');		 
		 }
	 }
	 else{
		$(".welcomediv").hide();
		 $('form').find('#welcomestep').remove();
		 firstlist = $('#lielemnts li').find('a:first').attr('id');
		 if(firstlist ==null)
		 {
			$('.lithank').trigger('click');
			 sortitems('sort','','');
			 currentform='';
		 }
		 else{
			 count= firstlist.match(/\d+/);
			 curvalind = 'fieldques'+parseInt(count).toString();
			 currentform=curvalind;
			 sortitems('sort','',curvalind);
			 //$('ques'+parseInt(count).toString()).trigger('click');
			 $('.lithank').trigger('click');
		 }
	 }
}

function sortfields(prevstep,idlists){
	lilength= $('#lielemnts li a.lielement').length;
	$("#lielemnts li a.lielement").each(function() {
		if(lilength != 1)
		{
			id = $(this).attr('id');
			count= id.match(/\d+/);
			filedid = 'fieldset#field'+$(this).attr("id");
			curvalind = 'fieldques'+parseInt(count).toString();
			indcuval = idlists.indexOf(curvalind);
			if(indcuval==0)
			{
				prevval=prevstep;	
				idnextval = idlists[indcuval+1]
			}
			else{
				prevval= idlists[indcuval-1];
				idnextval = idlists[indcuval+1]						
			}
			field= $('form').find(filedid);
			prev = field.find('.btn-prev');
			prev.attr('aria-controls',prevval);
			prev.removeClass("hidden");
			controls = field.find('.controls');
			controls.empty();
			controls.append('<button class="btn btn-default btn-next" type="button" aria-controls="'+idnextval+'" onclick="nextbtnclick(this);">Next</button><button class="btn btn-default btn-enter" type="button" aria-controls="'+idnextval+'" onclick="enterbtnclick(this);">Press <span class="f-string-em" >Enter</span></button>');	
		}
		lilength = parseInt(lilength)-1;
	});
}
function requiredclilck(rq)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(rq.checked){
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.prop('required',true);
			inpelmt.removeAttr('readonly');
			inpelmt.show();
			$("#chklblRead").removeAttr('checked');
			$("#chklblHidd").removeAttr('checked');
		}
		else if(eletype=="multipleChoice")
		{

		}
		else if(eletype=="singleChoice")
		{
			
		}
		else if(eletype=="imageChoice")
		{
			
		}
		else if(eletype=="matrixChoice")
		{
			
		}
		else if(eletype=="editorText")
		{
			inpelmt = $(fieldid).find("textarea");
			inpelmt.prop('required',true);
		}
	}
	else{
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.prop('required',false);
		}
		else if(eletype=="editorText")
		{
			inpelmt = $(fieldid).find("textarea");
			inpelmt.prop('required',false);
		}
	}
}
function readonlyclilck(rd)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(rd.checked){
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.prop('readonly',true);
			inpelmt.removeAttr('required');
			$("#chklblReq").removeAttr('checked');
		}

	}
	else{
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.prop('readonly',false);
		}
	}
}
function hiddenclilck(hdd)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(hdd.checked){
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.hide();
			inpelmt.removeAttr('required');
			$("#chklblReq").removeAttr('checked');
		}
	}
	else{
		if(eletype=="shortText"||eletype=="longText"||eletype=="emailAddress"||eletype=="phoneNumber"||eletype=="passwordField"||eletype=="dateField"||eletype=="numberField"||eletype=="fileUpload"||eletype=="dropdownChoice")
		{
			inpelmt = $(fieldid).find("input, textarea,select");
			inpelmt.show();
		}
	}
}
function welcomeimgChange(e)
{
	id=$(e).attr('id');
	filename = e.files[0];
	var fd = new FormData();
	var files = $('#'+id)[0].files;
	if(files.length > 0 ){
	   fd.append('file',files[0]);
		var xhr=new XMLHttpRequest();
		xhr.open("POST","/image_upload/",true);
		xhr.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var data=xhr.responseText;
				eleid = $("#helemtid").val();
				eletype = $("#helemttype").val();
				if(eleid != 'welcome')
				{
					fieldid= '#field'+eleid;
					imgwel = $(fieldid).find('img');
					imgwel.attr("src",data);
					if(eletype=="imageField")
					{
						$("#selectimagealign").trigger("change");
					}
				}
				else{
					imgwel = $("#welcomestep").find('img');
					imgwel.attr("src",data);
				}
			}};
		xhr.send(fd);
	}
	else{
		alert("Please select a file.");
	 }
}

function dateonchange(ev)
{
	minid = $("#inplblMinDate").val();
	maxid = $("#inplblMaxDate").val();
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	datefield = $(fieldid).find('input[type="date"]');
	datefield.removeAttr('max min ');
	if(minid.length!=0 && maxid.length!=0)
	{
		if(new Date(minid) <= new Date(maxid))
		{
			datefield.attr({"max" : maxid, "min" : minid });
		}
		else{
			datefield.removeAttr('max min ');
			alert("Max date should be greater than the Min date.")
		}	
	}
	else if(minid.length!=0 && maxid.length==0)
	{
		datefield.attr({ "min" : minid });
	}
	else if(minid.length==0 && maxid.length!=0)
	{
		datefield.attr({ "max" : maxid });
	}
}

function numberonchange(ev)
{
	minid = $("#inplblMinNumb").val();
	maxid = $("#inplblMaxNumb").val();
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	numberfield = $(fieldid).find('input[type="number"]');
	numberfield.removeAttr('max min ');
	if(minid.length!=0 && maxid.length!=0)
	{
		if(parseInt(maxid) > parseInt(minid))
		{
			numberfield.attr({"max" : maxid, "min" : minid });
		}
		else{
			numberfield.removeAttr('max min ');
			alert("Max number should be greater than the Min number.")
		}	
	}
	else if(minid.length!=0 && maxid.length==0)
	{
		numberfield.attr({ "min" : minid });
	}
	else if(minid.length==0 && maxid.length!=0)
	{
		numberfield.attr({ "max" : maxid });
	}
}
function longTextonChange(ev)
{
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	textfield = $(fieldid).find('textarea');
	textfield.attr('maxlength',ev.value);
}
function preventkeys(event){
	let unicode= event.which;
	if ([69, 187, 188, 189, 190,107,109].includes(unicode)) {
		event.preventDefault();
	}
}
function imgoptionOnchange(ev)
{
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	imgfield = $(fieldid).find('img');
	imgwidth = $("#image_val").text();
	if(ev.value=="left")
	{
		imgfield.css({"width":imgwidth, "margin-left":0, "margin-right":"auto"});
	}
	else if(ev.value=="right")
	{
		imgfield.css({"width":imgwidth, "margin-left":"auto", "margin-right":0});
	}
	else{
		imgfield.css({"width":imgwidth, "margin-left":"auto", "margin-right":"auto"});
	}
}

function fileacceptclick(ev)
{
	fileMax = $("#file_val").text();	
	chked = $("#filefields").find('input:checkbox:checked').map(function(){return $(this).next("label").text();}).get().join(",");
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	filefield = $(fieldid).find('input[type=file]');
	if(chked.length!=0)
	{
		filefield.attr({"maxfiles" : fileMax, "accept" : chked });
	}
	else{
		filefield.attr({"maxfiles" : fileMax, "accept" : '*' });
	}
}
function bindRatinbgScale(val)
{
	eleid = $("#helemtid").val();
	fieldid= '#field'+eleid;
	selectfield = $(fieldid).find('select');
	selectfield.empty();
	for (let i = 0; i < parseInt(val); i++) {
		selectfield.append(`<option value="${i+1}">
		${i+1}
   </option>`);
	}
	selectval = parseInt(val)/2;
	actval = Math.ceil(selectval);
	$('.rating-scale').barrating('clear');
	$('.rating-scale').barrating('destroy');
	$('.rating-scale').barrating('show', {
		theme: 'bars-square',
		showValues: true,
		showSelectedRating: false
	});
	$('.rating-scale').barrating('set', actval);
}

function Addoptnbtnclick()
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{

	}
	else if(eletype=="dropdownChoice")
	{
		optlenghth = $("#bindoptions").find('.divoptions').length;
		sellength = $(fieldid).find('select > option').length;
		updateval = 'Option '+parseInt(optlenghth+1);
		updatelbl = 'Option '+parseInt(optlenghth+1);
		var assignbtn = $("#chklblAssign")[0].checked ? 'yes' : 'no';
		if(assignbtn=='yes')
		{
			$("#bindoptions").append('<div class="row divoptions" id="'+(optlenghth+1)+'"><div class="col-sm-12 divalue"><input class="pro-controls" type="text" data-label="option" data-area="value" placeholder="value" value="'+updateval+'" onchange="optionvalOnchange('+(optlenghth+1)+')"><button class="btnopticons" onclick="Deleteoptnbtnclick('+(optlenghth+1)+');"> <i class="far fa-trash-alt"></i> </button></div><div class="col-sm-12 divlabel"><input class="pro-controls" type="text" data-label="option" data-area="label" value="'+updatelbl+'" onchange="optionlblOnchange('+(optlenghth+1)+')" placeholder="label"></div></div>')
		}
		else{
			$("#bindoptions").append('<div class="row divoptions" id="'+(optlenghth+1)+'"><div class="col-sm-12 divalue"><input class="pro-controls" type="text" data-label="option" data-area="value" placeholder="value" value="'+updateval+'" onchange="optionvalOnchange('+(optlenghth+1)+')"><button class="btnopticons" onclick="Deleteoptnbtnclick('+(optlenghth+1)+');"> <i class="far fa-trash-alt"></i> </button></div><div class="col-sm-12 divlabel"><input class="pro-controls" type="text" data-label="option" data-area="label" value="'+updatelbl+'" onchange="optionlblOnchange('+(optlenghth+1)+')" style="display: none;" placeholder="label"></div></div>')
		}	
		$(fieldid).find('select').append(new Option(updatelbl,updateval));
		$(fieldid).find('select').val($(fieldid).find('select option:first').val());
		var $options =  $(fieldid).find('select > option').clone();
		$('#selectdefault').empty();
		$('#selectdefault').append($options);
	}
}
function Removeoptnbtnclick()
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{

	}
	else if(eletype=="dropdownChoice")
	{
		$("#bindoptions").empty();
		selectfield = $(fieldid).find('select');
		selectfield.empty();
		$('#chklblAssign').prop('checked', false);
		$('#selectdefault').empty();
	}
}
function Deleteoptnbtnclick(ev)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{

	}
	else if(eletype=="dropdownChoice")
	{
		removeval = $('#'+ev).find('.divalue input').val();
		selectfield = $(fieldid).find('select');
		$('#'+ev).remove();
		$(fieldid).find('select option[value="'+removeval+'"]').remove();
		var $options =  $(fieldid).find('select > option').clone();
		$('#selectdefault').empty();
		$('#selectdefault').append($options);
	}
}

function Assignbtnclick(ev)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{

	}
	else if(eletype=="dropdownChoice")
	{
		selectfield = $(fieldid).find('select');
		selectfield.empty();
		if(ev.checked)
		{
		$('.divoptions').each(function(i, obj) {
			$(this).find('.divlabel input').show();
			lbltxt =  $(this).find('.divlabel input').val();
			lblval =  $(this).find('.divalue input').val();
			selectfield.append("<option value='"+lblval+"'>"+lbltxt+"</option>");
		});
	}
	else{
		$('.divoptions').each(function(i, obj) {
			$(this).find('.divlabel input').hide();
			lblval =  $(this).find('.divalue input').val();
			selectfield.append("<option value='"+lblval+"'>"+lblval+"</option>");
		});
	}
	var $options =  $(fieldid).find('select > option').clone();
	selectval = $('#selectdefault').val();
	$(fieldid).find('select').val(ev.value);
	$('#selectdefault').empty();
	$('#selectdefault').append($options);
	$('#selectdefault').val(selectval);
	$(fieldid).find('select').val(selectval);
	}
	else if(eletype=="imageChoice")
	{

	}
	else if(eletype=="matrixChoice")
	{

	}
}

function optionlblOnchange(ev)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{
		
	}
	else if(eletype=="dropdownChoice")
	{
		updateval = $('#'+ev).find('.divalue input').val();
		updatewith = $('#'+ev).find('.divlabel input').val();
		$(fieldid).find('select option[value="'+updateval+'"]').text(updatewith);
		var $options =  $(fieldid).find('select > option').clone();
		$('#selectdefault').empty();
		$('#selectdefault').append($options);
	}
}
function optionvalOnchange(ev)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	if(eletype=="multipleChoice")
	{

	}
	else if(eletype=="singleChoice")
	{
		
	}
	else if(eletype=="dropdownChoice")
	{
		var options = $("#bindoptions");        
		var index = options.find("#"+ev).index();
		index = parseInt(index)+1;
		updateval = $('#'+ev).find('.divalue input').val();
		if(updateval.length!=0)
		{
		removeval = $('#'+ev).find('.divlabel input').val();
		selectfield = $(fieldid).find('select');
		sellength = $(fieldid).find('select > option').length;
		$(fieldid).find('select option:contains('+removeval+')').remove();
		updatelbl = $('#'+ev).find('.divlabel input').val();
		var assignbtn = $("#chklblAssign")[0].checked ? 'yes' : 'no';
		if(assignbtn=='yes')
		{
		if(sellength == parseInt(index))
		{
		ev1 = parseInt(index)-1;
		$(fieldid).find('select :nth-child('+parseInt(ev1)+')').after("<option value='"+updateval+"'>"+updatelbl+"</option>");
		}
		else{
			$(fieldid).find('select :nth-child('+parseInt(index)+')').before("<option value='"+updateval+"'>"+updatelbl+"</option>");
		}
	}
	else{
		if(sellength == parseInt(index))
		{
		ev1 = parseInt(index)-1;
		$(fieldid).find('select :nth-child('+parseInt(ev1)+')').after("<option value='"+updateval+"'>"+updateval+"</option>");
		}
		else{
			$(fieldid).find('select :nth-child('+parseInt(index)+')').before("<option value='"+updateval+"'>"+updateval+"</option>");
		}
	}
		$(fieldid).find('select').val($(fieldid).find('select option:first').val());
		var $options =  $(fieldid).find('select > option').clone();
		$('#selectdefault').empty();
		$('#selectdefault').append($options);
	}
	}
}
function seldefaultChange(ev)
{
	eleid = $("#helemtid").val();
	eletype = $("#helemttype").val();
	fieldid= '#field'+eleid;
	$(fieldid).find('select').val(ev.value);
}
function publishclick(ev)
{
    if(ev.checked)
    {
        var options1 = {
        hour: {
            value: 0,
            min: 0,
            max: 24,
            step: 1,
            symbol: "hrs"
        },
        minute: {
            value: 0,
            min: 0,
            max: 60,
            step: 1,
            symbol: "mins"
        },
        direction: "increment", // increment or decrement
        inputHourTextbox: null, // hour textbox
        inputMinuteTextbox: null, // minutes textbox
        postfixText: "", // text to display after the input fields
        numberPaddingChar: '0' // number left padding character ex: 00052
    };
    $(".timerdiv").timesetter(options1).setHour(0);
    $(".maintimerdiv").hide();
    $('#timerBtn').prop('checked', false);
    $("#timerModel").modal('show');
    }
    else
    {
         formId = $("#formId").val();
         $.ajax({
            type:"POST",
            url: "/unpublish_form/",
            data: {'formID':formId},
            success: function(data) 
            { 
                 $("#pubdiv").hide();
            }
        });
    }
}
function inputeditoronChange(ev)
{
	val = $("#"+ev).val();
	var myInstance = $("#"+currentform).find(".CodeMirror")[0].CodeMirror;
	myInstance.setOption("mode", val);
}
function updateform(ev)
{
	var editorcontent = '';
    formcontent = $("#formelements")[0].innerHTML;
    thankcontent = $(".thankyou")[0].innerHTML;
    formName = $("#formName").val();
    tempdiv = $(".tempdiv");
    tempdiv.html(formcontent);
    tempdiv.find('.br-widget').remove();
    tempdiv.find('.rating-scale').removeAttr('autocomplete style');
    tempdiv.find('.audioclck').attr("onclick","audioclick(this,'audiobody')");
    tempdiv.find('.videoclck').attr("onclick","videoclick(this,'videobody')");
    formId = $("#formId").val();
	editorfield = tempdiv.find('.editorcontrol');
	tempdiv.find('.CodeMirror').remove();
	tempdiv.find('.editorcontrol').removeAttr('autocomplete style');
	fcontent = $(".tempdiv")[0].innerHTML;
	if(editorfield.length > 0)
	{
		editorcontent = '<link rel="stylesheet" href="{% static "assets/form/codemirror.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/material-ocean.css" %}"><link rel="stylesheet" href="{% static "assets/form/show-hint.css" %}"><script src="{% static "assets/form/jquery-ui.js" %}"></script><script src="{% static "assets/form/codemirror.min.js" %}"></script><script src="{% static "assets/form/xml.js" %}"></script><script src="{% static "assets/form/javascript.js" %}"></script><script src="{% static "assets/form/css.js" %}"></script><script src="{% static "assets/form/htmlmixed.js" %}"></script><script src="{% static "assets/form/matchbrackets.js" %}"></script><script src="{% static "assets/form/show-hint.js" %}"></script><script src="{% static "assets/form/javascript-hint.js" %}"></script><script src="{% static "assets/form/html-hint.js" %}"></script><script src="{% static "assets/form/jsx.min.js" %}"></script><script src="{% static "assets/form/comment.min.js" %}"></script><script src="{% static "assets/form/active-line.min.js" %}"></script><script src="{% static "assets/form/foldgutter.min.js" %}"></script><script src="{% static "assets/form/brace-fold.min.js" %}"></script><script src="{% static "assets/form/indent-fold.min.js" %}"></script><script src="{% static "assets/form/closebrackets.min.js" %}"></script><script src="{% static "assets/form/matchbrackets.min.js" %}"></script><script src="{% static "assets/form/python.min.js" %}"></script><script src="{% static "assets/form/xml-hint.js" %}"></script><script src="{% static "assets/form/css-hint.js" %}"></script><script src="{% static "assets/form/sublime.js" %}"></script><script src="{% static "assets/form/clike.js" %}"></script><script src="{% static "assets/form/php.js" %}"></script>';
	}
	else{
		editorcontent = ''
	}
	var timer = '0.00';
    $(".tempdiv").empty();
    content = '';
    hourval = $('#pubtimer').find('#txtHours').val();
    minval = $('#pubtimer').find('#txtMinutes').val();
    if( parseInt(minval)!=0  && minval != null)
    {
        hourMinute = parseInt(hourval)*60;
        tominutes = hourMinute + parseInt(minval)
        totalseconds = tominutes*60;
		timer = totalseconds;
        clockcontent = '<div class="row"><div class="col-12 col-xs-12"><div class="clock" ></div><div class="message"></div><script type="text/javascript">var clock;$(document).ready(function() {clock = $(".clock").FlipClock('+totalseconds+', {clockFace: "MinuteCounter",countdown: true,callbacks: {stop: function() {location.reload();}}});});</script></div></div>'
        content =  '{% load static %}{% block content %}<!DOCTYPE html><html lang="en" ><head><meta charset="UTF-8"><title> '+formName+' - TalentSumo</title><link rel="icon" href="{% static "assets/img/logo.png" %}"  type="image/png"><script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;900&amp;display=swap"><link rel="stylesheet" href="{% static "assets/form/tailwind.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/normalize.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/animate.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/bootstrap.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/flipclock.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/style.css" %}"><link rel="stylesheet" href="{% static "assets/form/bars-square.css" %}"><link rel="stylesheet" href="{% static "assets/form/asPieProgress.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/fontawesome.min.css" %}"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css"><script src="{% static "assets/form/fontawesome.min.js" %}"></script><script src="{% static "assets/form/jquery-2.2.4.min.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/bootstrap.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.barrating.min.js" %}"></script><script src="{% static "assets/form/jquery-asPieProgress.min.js" %}"></script><script src="{% static "assets/form/flipclock.min.js" %}"></script><script src="{% static "assets/form/inline.js" %}"></script><script src="{% static "assets/form/jQuery.slider.js" %}"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>'+editorcontent+'</head><body><div class="container"><div class="row"><div class="col-12 col-xs-12">'+clockcontent+' <section class="multi-step-form"><input type="hidden" id="formName" name="formName" class="formName"  value="'+formName+'"><input type="hidden" id="formId" name="formId" class="formId"  value="'+formId+'"><form  id="formelements">{% csrf_token %}'+fcontent+'</form></section><section class="thankyou">'+thankcontent+'</section></div></div></div><script src="{% static "assets/form/script3.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/clipboard.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/adapter-latest.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><div class="modal fade modal-fullscreen footer-to-bottom" id="videoModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Video</h4> </div> <div class="modal-body" ><div class="container" id="videobody"><div class="rec_container"> <div class="video1" id="divupload"><div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Video </div> <label for="upload" id="lupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="upload" accept="video/mp4,video/x-m4v,video/*" data-label="videobody" data-value="video" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted></video> <div class="buttons"> <div class="text" id="videotxt">Record Video </div> <button id="rec" data-label="videobody" data-value="video"  onclick="onBtnRecordClicked(this)" class="vidstrRec"><i class="fas fa-circle"></i></button> <button id="stop" class="vidstpRec" data-label="videobody" data-value="video"  onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp4" style="display:none;" name="mediarecorder.mp4" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"><img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div><div class="modal fade modal-fullscreen footer-to-bottom" id="audioModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Audio</h4> </div> <div class="modal-body" > <div class="container" id="audiobody"><div class="rec_container"> <div class="video1" id="divupload"> <div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Audio </div> <label for="aupload" id="alupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="aupload" accept="audio/mp3,audio/*;capture=microphone" data-label="audiobody" data-value="audio" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted width="150px" Height="150px"></video> <div id="img_rec" style="display:none;"><img src="{% static "assets/img/giphy.gif" %}" alt="Recording audio"  width="250" /></div><div class="buttons"> <div class="text" id="videotxt">Record Audio </div> <button id="rec" class="audstrRec"  data-label="audiobody" data-value="audio" onclick="onBtnRecordClicked(this)"><i class="fas fa-circle"></i></button> <button id="stop" class="audstpRec" data-label="audiobody" data-value="audio" onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp3" style="display:none;" name="mediarecorder.mp3" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"> <img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div></body></html>{% endblock %}';
    }
    else
    {
		timer = '0.00';
        content =  '{% load static %}{% block content %}<!DOCTYPE html><html lang="en" ><head><meta charset="UTF-8"><title> '+formName+' - TalentSumo</title><link rel="icon" href="{% static "assets/img/logo.png" %}"  type="image/png"><script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;900&amp;display=swap"><link rel="stylesheet" href="{% static "assets/form/tailwind.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/normalize.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/animate.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/bootstrap.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/flipclock.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/style.css" %}"><link rel="stylesheet" href="{% static "assets/form/bars-square.css" %}"><link rel="stylesheet" href="{% static "assets/form/asPieProgress.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/fontawesome.min.css" %}"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css"><script src="{% static "assets/form/fontawesome.min.js" %}"></script><script src="{% static "assets/form/jquery-2.2.4.min.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/bootstrap.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.barrating.min.js" %}"></script><script src="{% static "assets/form/jquery-asPieProgress.min.js" %}"></script><script src="{% static "assets/form/flipclock.min.js" %}"></script><script src="{% static "assets/form/inline.js" %}"></script><script src="{% static "assets/form/jQuery.slider.js" %}"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>'+editorcontent+'</head><body><div class="container"><div class="row"><div class="col-12 col-xs-12"><section class="multi-step-form"><input type="hidden" id="formName" name="formName" class="formName"  value="'+formName+'"><input type="hidden" id="formId" name="formId" class="formId"  value="'+formId+'"><form  id="formelements">{% csrf_token %}'+fcontent+'</form></section><section class="thankyou">'+thankcontent+'</section></div></div></div><script src="{% static "assets/form/script3.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/clipboard.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/adapter-latest.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><div class="modal fade modal-fullscreen footer-to-bottom" id="videoModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Video</h4> </div> <div class="modal-body" ><div class="container" id="videobody"><div class="rec_container"> <div class="video1" id="divupload"><div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Video </div> <label for="upload" id="lupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="upload" accept="video/mp4,video/x-m4v,video/*" data-label="videobody" data-value="video" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted></video> <div class="buttons"> <div class="text" id="videotxt">Record Video </div> <button id="rec" data-label="videobody" data-value="video"  onclick="onBtnRecordClicked(this)" class="vidstrRec"><i class="fas fa-circle"></i></button> <button id="stop" class="vidstpRec" data-label="videobody" data-value="video"  onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp4" style="display:none;" name="mediarecorder.mp4" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"><img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div><div class="modal fade modal-fullscreen footer-to-bottom" id="audioModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Audio</h4> </div> <div class="modal-body" > <div class="container" id="audiobody"><div class="rec_container"> <div class="video1" id="divupload"> <div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Audio </div> <label for="aupload" id="alupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="aupload" accept="audio/mp3,audio/*;capture=microphone" data-label="audiobody" data-value="audio" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted width="150px" Height="150px"></video> <div id="img_rec" style="display:none;"><img src="{% static "assets/img/giphy.gif" %}" alt="Recording audio"  width="250" /></div><div class="buttons"> <div class="text" id="videotxt">Record Audio </div> <button id="rec" class="audstrRec"  data-label="audiobody" data-value="audio" onclick="onBtnRecordClicked(this)"><i class="fas fa-circle"></i></button> <button id="stop" class="audstpRec" data-label="audiobody" data-value="audio" onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp3" style="display:none;" name="mediarecorder.mp3" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"> <img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div></body></html>{% endblock %}';
    }
    if(content.length!=0)
    {
    $.ajax({
        type:"POST",
        url: "/publish_form/",
        data: {'publishcontent': content,'formID':formId,'formName':formName,'timer':timer},
        success: function(data) 
        { 
            alert("Form Updated Successfully");
        }
    });
    }
}

function timerswitchclk(ev)
{
    if(ev.checked)
    {
        $(".maintimerdiv").show();
        $('#pubtimer').find('#txtHours').val(0);
        $('#pubtimer').find('#txtMinutes').val(0);
    }
    else
    {
        $(".maintimerdiv").hide();
    }
}

function modelOK()
{
	var editorcontent = '';
    formcontent = $("#formelements")[0].innerHTML;
    thankcontent = $(".thankyou")[0].innerHTML;
    formName = $("#formName").val();
    tempdiv = $(".tempdiv");
    tempdiv.html(formcontent);
    tempdiv.find('.br-widget').remove();
    tempdiv.find('.rating-scale').removeAttr('autocomplete style');
    tempdiv.find('.audioclck').attr("onclick","audioclick(this,'audiobody')");
    tempdiv.find('.videoclck').attr("onclick","videoclick(this,'videobody')");
    formId = $("#formId").val();
	editorfield = tempdiv.find('.editorcontrol');
	tempdiv.find('.CodeMirror').remove();
	tempdiv.find('.editorcontrol').removeAttr('autocomplete style');
	fcontent = $(".tempdiv")[0].innerHTML;
	if(editorfield.length > 0)
	{
		editorcontent = '<link rel="stylesheet" href="{% static "assets/form/codemirror.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/material-ocean.css" %}"><link rel="stylesheet" href="{% static "assets/form/show-hint.css" %}"><script src="{% static "assets/form/jquery-ui.js" %}"></script><script src="{% static "assets/form/codemirror.min.js" %}"></script><script src="{% static "assets/form/xml.js" %}"></script><script src="{% static "assets/form/javascript.js" %}"></script><script src="{% static "assets/form/css.js" %}"></script><script src="{% static "assets/form/htmlmixed.js" %}"></script><script src="{% static "assets/form/matchbrackets.js" %}"></script><script src="{% static "assets/form/show-hint.js" %}"></script><script src="{% static "assets/form/javascript-hint.js" %}"></script><script src="{% static "assets/form/html-hint.js" %}"></script><script src="{% static "assets/form/jsx.min.js" %}"></script><script src="{% static "assets/form/comment.min.js" %}"></script><script src="{% static "assets/form/active-line.min.js" %}"></script><script src="{% static "assets/form/foldgutter.min.js" %}"></script><script src="{% static "assets/form/brace-fold.min.js" %}"></script><script src="{% static "assets/form/indent-fold.min.js" %}"></script><script src="{% static "assets/form/closebrackets.min.js" %}"></script><script src="{% static "assets/form/matchbrackets.min.js" %}"></script><script src="{% static "assets/form/python.min.js" %}"></script><script src="{% static "assets/form/xml-hint.js" %}"></script><script src="{% static "assets/form/css-hint.js" %}"></script><script src="{% static "assets/form/sublime.js" %}"></script><script src="{% static "assets/form/clike.js" %}"></script><script src="{% static "assets/form/php.js" %}"></script>';
	}
	else{
		editorcontent = '';
	}
	var timer = '0.00';
    $(".tempdiv").empty();
    content = '';
    var timbtn = $("#timerBtn")[0].checked ? 'yes' : 'no';
    if(timbtn=='yes')
    {
        hourval = $('.timerdiv').find('#txtHours').val();
        minval = $('.timerdiv').find('#txtMinutes').val();
        if( parseInt(minval)!=0  && minval != null)
        {
            hourMinute = parseInt(hourval)*60;
            tominutes = hourMinute + parseInt(minval)
            totalseconds = tominutes*60;
			timer = totalseconds;
            clockcontent = '<div class="row"><div class="col-12 col-xs-12"><div class="clock" ></div><div class="message"></div><script type="text/javascript">var clock;$(document).ready(function() {clock = $(".clock").FlipClock('+totalseconds+', {clockFace: "MinuteCounter",countdown: true,callbacks: {stop: function() {location.reload();}}});});</script></div></div>'
            content =  '{% load static %}{% block content %}<!DOCTYPE html><html lang="en" ><head><meta charset="UTF-8"><title> '+formName+' - TalentSumo</title><link rel="icon" href="{% static "assets/img/logo.png" %}"  type="image/png"><script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;900&amp;display=swap"><link rel="stylesheet" href="{% static "assets/form/tailwind.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/normalize.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/animate.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/bootstrap.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/flipclock.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/style.css" %}"><link rel="stylesheet" href="{% static "assets/form/bars-square.css" %}"><link rel="stylesheet" href="{% static "assets/form/asPieProgress.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/fontawesome.min.css" %}"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css"><script src="{% static "assets/form/fontawesome.min.js" %}"></script><script src="{% static "assets/form/jquery-2.2.4.min.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/bootstrap.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.barrating.min.js" %}"></script><script src="{% static "assets/form/jquery-asPieProgress.min.js" %}"></script><script src="{% static "assets/form/flipclock.min.js" %}"></script><script src="{% static "assets/form/inline.js" %}"></script><script src="{% static "assets/form/jQuery.slider.js" %}"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>'+editorcontent+'</head><body><div class="container"><div class="row"><div class="col-12 col-xs-12">'+clockcontent+'<section class="multi-step-form"><input type="hidden" id="formName" name="formName" class="formName"  value="'+formName+'"><input type="hidden" id="formId" name="formId" class="formId"  value="'+formId+'"><form  id="formelements">{% csrf_token %}'+fcontent+'</form></section><section class="thankyou">'+thankcontent+'</section></div></div></div><script src="{% static "assets/form/script3.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/clipboard.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/adapter-latest.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><div class="modal fade modal-fullscreen footer-to-bottom" id="videoModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Video</h4> </div> <div class="modal-body" ><div class="container" id="videobody"><div class="rec_container"> <div class="video1" id="divupload"><div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Video </div> <label for="upload" id="lupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="upload" accept="video/mp4,video/x-m4v,video/*" data-label="videobody" data-value="video" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted></video> <div class="buttons"> <div class="text" id="videotxt">Record Video </div> <button id="rec" data-label="videobody" data-value="video"  onclick="onBtnRecordClicked(this)" class="vidstrRec"><i class="fas fa-circle"></i></button> <button id="stop" class="vidstpRec" data-label="videobody" data-value="video"  onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp4" style="display:none;" name="mediarecorder.mp4" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"><img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div><div class="modal fade modal-fullscreen footer-to-bottom" id="audioModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Audio</h4> </div> <div class="modal-body" > <div class="container" id="audiobody"><div class="rec_container"> <div class="video1" id="divupload"> <div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Audio </div> <label for="aupload" id="alupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="aupload" accept="audio/mp3,audio/*;capture=microphone" data-label="audiobody" data-value="audio" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted width="150px" Height="150px"></video><div id="img_rec" style="display:none;"><img src="{% static "assets/img/giphy.gif" %}" alt="Recording audio"  width="250" /></div> <div class="buttons"> <div class="text" id="videotxt">Record Audio </div> <button id="rec" class="audstrRec"  data-label="audiobody" data-value="audio" onclick="onBtnRecordClicked(this)"><i class="fas fa-circle"></i></button> <button id="stop" class="audstpRec" data-label="audiobody" data-value="audio" onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp3" style="display:none;" name="mediarecorder.mp3" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"> <img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div></body></html>{% endblock %}';
        }
        else
        {
			timer = '0.00';
            content =  '{% load static %}{% block content %}<!DOCTYPE html><html lang="en" ><head><meta charset="UTF-8"><title> '+formName+' - TalentSumo</title><link rel="icon" href="{% static "assets/img/logo.png" %}"  type="image/png"><script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;900&amp;display=swap"><link rel="stylesheet" href="{% static "assets/form/tailwind.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/normalize.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/animate.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/bootstrap.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/flipclock.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/style.css" %}"><link rel="stylesheet" href="{% static "assets/form/bars-square.css" %}"><link rel="stylesheet" href="{% static "assets/form/asPieProgress.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/fontawesome.min.css" %}"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css"><script src="{% static "assets/form/fontawesome.min.js" %}"></script><script src="{% static "assets/form/jquery-2.2.4.min.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/bootstrap.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.barrating.min.js" %}"></script><script src="{% static "assets/form/jquery-asPieProgress.min.js" %}"></script><script src="{% static "assets/form/flipclock.min.js" %}"></script><script src="{% static "assets/form/inline.js" %}"></script><script src="{% static "assets/form/jQuery.slider.js" %}"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>'+editorcontent+'</head><body><div class="container"><div class="row"><div class="col-12 col-xs-12"><section class="multi-step-form"><input type="hidden" id="formName" name="formName" class="formName"  value="'+formName+'"><input type="hidden" id="formId" name="formId" class="formId"  value="'+formId+'"><form  id="formelements">{% csrf_token %}'+fcontent+'</form></section><section class="thankyou">'+thankcontent+'</section></div></div></div><script src="{% static "assets/form/script3.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/clipboard.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/adapter-latest.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><div class="modal fade modal-fullscreen footer-to-bottom" id="videoModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Video</h4> </div> <div class="modal-body" ><div class="container" id="videobody"><div class="rec_container"> <div class="video1" id="divupload"><div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Video </div> <label for="upload" id="lupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="upload" accept="video/mp4,video/x-m4v,video/*" data-label="videobody" data-value="video" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted></video> <div class="buttons"> <div class="text" id="videotxt">Record Video </div> <button id="rec" data-label="videobody" data-value="video"  onclick="onBtnRecordClicked(this)" class="vidstrRec"><i class="fas fa-circle"></i></button> <button id="stop" class="vidstpRec" data-label="videobody" data-value="video"  onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp4" style="display:none;" name="mediarecorder.mp4" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"><img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div><div class="modal fade modal-fullscreen footer-to-bottom" id="audioModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Audio</h4> </div> <div class="modal-body" > <div class="container" id="audiobody"><div class="rec_container"> <div class="video1" id="divupload"> <div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Audio </div> <label for="aupload" id="alupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="aupload" accept="audio/mp3,audio/*;capture=microphone" data-label="audiobody" data-value="audio" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted width="150px" Height="150px"></video> <div id="img_rec" style="display:none;"><img src="{% static "assets/img/giphy.gif" %}" alt="Recording audio"  width="250" /></div><div class="buttons"> <div class="text" id="videotxt">Record Audio </div> <button id="rec" class="audstrRec"  data-label="audiobody" data-value="audio" onclick="onBtnRecordClicked(this)"><i class="fas fa-circle"></i></button> <button id="stop" class="audstpRec" data-label="audiobody" data-value="audio" onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp3" style="display:none;" name="mediarecorder.mp3" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"> <img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div></body></html>{% endblock %}';
        }
    }
    else
    {
		timer = '0.00';
        content =  '{% load static %}{% block content %}<!DOCTYPE html><html lang="en" ><head><meta charset="UTF-8"><title> '+formName+' - TalentSumo</title><link rel="icon" href="{% static "assets/img/logo.png" %}"  type="image/png"><script>document.documentElement.className = document.documentElement.className.replace("no-js","js");</script><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;900&amp;display=swap"><link rel="stylesheet" href="{% static "assets/form/tailwind.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/normalize.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/animate.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/bootstrap.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/flipclock.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/style.css" %}"><link rel="stylesheet" href="{% static "assets/form/bars-square.css" %}"><link rel="stylesheet" href="{% static "assets/form/asPieProgress.min.css" %}"><link rel="stylesheet" href="{% static "assets/form/fontawesome.min.css" %}"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.css"><script src="{% static "assets/form/fontawesome.min.js" %}"></script><script src="{% static "assets/form/jquery-2.2.4.min.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/bootstrap.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.barrating.min.js" %}"></script><script src="{% static "assets/form/jquery-asPieProgress.min.js" %}"></script><script src="{% static "assets/form/flipclock.min.js" %}"></script><script src="{% static "assets/form/inline.js" %}"></script><script src="{% static "assets/form/jQuery.slider.js" %}"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-lite.js"></script>'+editorcontent+'</head><body><div class="container"><div class="row"><div class="col-12 col-xs-12"><section class="multi-step-form"><input type="hidden" id="formName" name="formName" class="formName"  value="'+formName+'"><input type="hidden" id="formId" name="formId" class="formId"  value="'+formId+'"><form  id="formelements">{% csrf_token %}'+fcontent+'</form></section><section class="thankyou">'+thankcontent+'</section></div></div></div><script src="{% static "assets/form/script3.js" %}"></script><script src="{% static "assets/form/jquery.MultiFile.js" %}"></script><script src="{% static "assets/form/clipboard.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><script src="{% static "assets/form/adapter-latest.js" %}"></script><script src="{% static "assets/form/jquery.validate.min.js" %}"></script><div class="modal fade modal-fullscreen footer-to-bottom" id="videoModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Video</h4> </div> <div class="modal-body" ><div class="container" id="videobody"><div class="rec_container"> <div class="video1" id="divupload"><div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Video </div> <label for="upload" id="lupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="upload" accept="video/mp4,video/x-m4v,video/*" data-label="videobody" data-value="video" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted></video> <div class="buttons"> <div class="text" id="videotxt">Record Video </div> <button id="rec" data-label="videobody" data-value="video"  onclick="onBtnRecordClicked(this)" class="vidstrRec"><i class="fas fa-circle"></i></button> <button id="stop" class="vidstpRec" data-label="videobody" data-value="video"  onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp4" style="display:none;" name="mediarecorder.mp4" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"><img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div><div class="modal fade modal-fullscreen footer-to-bottom" id="audioModel" tabindex="-1" role="dialog" aria-hidden="true"> <div class="modal-dialog animated fadeInDown"> <div class="modal-content"> <div class="modal-header"> <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> <h4 class="modal-title">Record Audio</h4> </div> <div class="modal-body" > <div class="container" id="audiobody"><div class="rec_container"> <div class="video1" id="divupload"> <div class="hover_bkgr_fricc"> <span class="helper"></span> <div> <p id="counter"></p> </div></div> <div class="text">Upload Audio </div> <label for="aupload" id="alupload"> <i class="fa fa-upload" aria-hidden="true"></i> </label> <input type="file" name="upload" class="upload" id="aupload" accept="audio/mp3,audio/*;capture=microphone" data-label="audiobody" data-value="audio" onchange="onBtnUploadChanged(this)" /></div><div class="video" id="divideo"> <video id="live" controls autoplay playsinline muted width="150px" Height="150px"></video><div id="img_rec" style="display:none;"><img src="{% static "assets/img/giphy.gif" %}" alt="Recording audio"  width="250" /></div><div class="buttons"> <div class="text" id="videotxt">Record Audio </div> <button id="rec" class="audstrRec"  data-label="audiobody" data-value="audio" onclick="onBtnRecordClicked(this)"><i class="fas fa-circle"></i></button> <button id="stop" class="audstpRec" data-label="audiobody" data-value="audio" onclick="onBtnStopClicked(this)" disabled style="display:none"><i class="fa fa-stop-circle" aria-hidden="true"></i></button> </div> <video id="playback" controls autoplay style="display:none;"></video> <a id="downloadLink" download="mediarecorder.mp3" style="display:none;" name="mediarecorder.mp3" href></a></div><div id="divnot">Please accept browser permissions for video and audio. Wait for upto 30 seconds to detect the camera.</div><div class="video2" id="divprogress" style="display:none;"> <svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate id="animationid" attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="120s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20"></text></svg> <div class="upload-box-label" id="u_status">Uploading</div></div><div class="video3" id="divprogresscomp" style="display:none;"><svg id="animated" viewbox="0 0 100 100"> <circle cx="50" cy="50" r="45" fill="#fff"/> <path fill="none" stroke-linecap="round" stroke-width="5" stroke="#16205F" stroke-dasharray="251.2,0" d="M50 10 a 40 40 0 0 1 0 80 a 40 40 0 0 1 0 -80"> <animate attributeName="stroke-dasharray" from="0,251.2" to="251.2,0" dur="1s"/> </path> <text id="count" x="50" y="50" text-anchor="middle" dy="7" font-size="20" ><i id="countyes" class="fa fa-check" aria-hidden="true"></i></text></svg> <div class="upload-box-label" id="u_status">Uploaded</div> <div class="upload-box-label" id="u_status1">Uploaded</div> <div class="upload-box-label" style="display:none;" id="up_urldiv"> <a id="up_url" href="#"> url </a> <button id="copy" data-clipboard-text="123" title="Copy Video URL!"><i class="fa fa-copy"></i></button></div> <div class="upload-box-label" id="url_text" style="display:none;">Copy the above url and paste it in the form, Then close the tab.</div> <div class="upload-box-label" id="video_prev" style="display:none;"> <div class="v_class"><span>Your Interview Preview is here:</span></div> <div class="v_class"><video id="preview_video" src="#" type="video/mp4" controls></video></div> </div> <div class="upload-box-label" id="restart_btn" style="display:none;"> <button id="rerecord" class="btn btn-info btn-sm" onclick="onBtnReRecordClicked(this)">Not Happy ? Record again.</button> </div></div></div><div class="video_container"> <img src="{% static "assets/img/brand_new.jpg" %}" alt="Learn more skills"></div></div> </div> </div> </div> </div></body></html>{% endblock %}';
    }
    if(content.length!=0)
    {
        $.ajax({
        type:"POST",
        url: "/publish_form/",
        data: {'publishcontent': content,'formID':formId,'formName':formName,'timer':timer},
        success: function(data) 
        { 
             $("#timerModel").modal('hide');
            $("#puburl").val(data);
            $("#pubdiv").show();
        }
    }); 
    }
}

	function audioclick(ev)
	{
	    alert("audio video will work only after publish!");
	}
		function videoclick(ev)
	{
	    alert("audio video will work only after publish!");
	}
	